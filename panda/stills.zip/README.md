extracted by ffmpeg from https://www.youtube.com/watch?v=ZwChSexiPgQ
